#!/usr/bin/env python3
"""
Telegram Shop Bot (aiogram v3)

Features:
- Catalog of PC devices
- Cart (add/remove/view)
- Checkout flow with simulated payment
- Orders saved to orders.json
- Admin /orders command + order details + mark shipped

Requirements:
pip install aiogram python-dotenv
"""

import os
import json
import asyncio
import time
import logging
from uuid import uuid4
from functools import wraps
from datetime import datetime
from typing import Dict, Any

from aiogram import Bot, Dispatcher, types, F, Router
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message
from aiogram.filters.command import Command
from aiogram.filters.callback_data import CallbackData
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.enums import ParseMode

# --- CONFIG ---
import os

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = os.getenv("ADMIN_ID")

# Перевірка, чи змінні оточення були встановлені
if not BOT_TOKEN:
    print("Error: BOT_TOKEN environment variable not set.")
    exit(1)

if not ADMIN_ID:
    print("Error: ADMIN_ID environment variable not set.")
    exit(1)

# Конвертуємо ADMIN_ID у ціле число, оскільки getenv повертає рядок
ADMIN_ID = int(ADMIN_ID)

# --- logging ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- Initialization ---
dp = Dispatcher(storage=MemoryStorage())
bot = Bot(token=BOT_TOKEN)
router = Router()

ORDERS_FILE = "orders.json"

# --- Sample products (invented) ---
PRODUCTS = {
    "p001": {"id": "p001", "name": "Механічна клавіатура RedStorm K8", "price": 79.99, "stock": 12, "desc": "RGB, Cherry-like switches, USB-C", "photo_id": "AgACAgIAAxkBAAM3aNUi5BWdnV3EMgHXSsr1beLptmYAAk__MRswAbFKCoYCDM8-gywBAAMCAAN5AAM2BA"},
    "p002": {"id": "p002", "name": "Оптична миша SilentPro M3", "price": 29.50, "stock": 25, "desc": "2400 DPI, безшумні кнопки", "photo_id": "AgACAgIAAxkBAAM5aNUi96Rc3QABHAs1qfI1SOSSzz5jAAJU_zEbMAGxSop9z6ZYCe3LAQADAgADeAADNgQ"},
    "p003": {"id": "p003", "name": "Ігрова миша HyperX Nova", "price": 54.00, "stock": 8, "desc": "6400 DPI, програмовані кнопки", "photo_id": "AgACAgIAAxkBAAM1aNUiyqVCLSuURhuPEcE8ZyVM7OUAAk7_MRswAbFK5U8-QTEUnZEBAAMCAAN4AAM2BA"},
    "p004": {"id": "p004", "name": "Геймерська гарнітура EchoSound V2", "price": 69.90, "stock": 10, "desc": "Стерео, мікрофон з шумоподавленням", "photo_id": "AgACAgIAAxkBAAMxaNUinvsLY4jiFqq9nUMjkQ29T1cAAkv_MRswAbFKuNvpraYM1jEBAAMCAAN5AAM2BA"},
    "p005": {"id": "p005", "name": "Підставка для ноутбука CoolLift", "price": 19.99, "stock": 30, "desc": "Алюмінієва, регульована", "photo_id": "AgACAgIAAxkBAAMvaNUihPxJB2M_muFjG_Mbt5HvUfQAAkn_MRswAbFKvg-AORBBfB8BAAMCAAN4AAM2BA"},
    "p006": {"id": "p006", "name": "Килимок для миші XXL Glide", "price": 14.99, "stock": 50, "desc": "Великий, гумове підставлення", "photo_id": "AgACAgIAAxkBAAMzaNUitzrnLlkAAY49olxnb1NPusvDAAJN_zEbMAGxSi5ZTqvjIlVSAQADAgADeAADNgQ"},
    "p007": {"id": "p007", "name": "Вебкамера ClearView 1080p", "price": 39.99, "stock": 15, "desc": "Full HD, вбудований мікрофон", "photo_id": "AgACAgIAAxkBAAMtaNUia5rWbFDfAAFhX3WYOeAnd2MVAAJH_zEbMAGxSuVHQfn-C5oMAQADAgADeAADNgQ"},
    "p008": {"id": "p008", "name": "Підставка-підсилювач USB Hub 4 порти", "price": 24.90, "stock": 20, "desc": "USB 3.0, LED індикатор", "photo_id": "AgACAgIAAxkBAAM7aNUjB0rBX6eAtEYy6gcddCWdfaoAAmD_MRswAbFKWXWagaH8ry0BAAMCAAN4AAM2BA"}
}

# --- FSM States ---
class Checkout(StatesGroup):
    ask_name = State()
    ask_phone = State()
    ask_address = State()
    confirm = State()

# --- Callback data ---
class CatalogCallback(CallbackData, prefix="cat"):
    action: str
    product_id: str

class CartCallback(CallbackData, prefix="cart"):
    action: str
    product_id: str

class OrderCallback(CallbackData, prefix="order"):
    action: str
    order_id: str

# --- Utilities ---
def load_orders():
    if not os.path.exists(ORDERS_FILE):
        with open(ORDERS_FILE, "w", encoding="utf-8") as f:
            json.dump([], f, indent=2, ensure_ascii=False)
        return []
    with open(ORDERS_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def save_orders(orders):
    with open(ORDERS_FILE, "w", encoding="utf-8") as f:
        json.dump(orders, f, indent=2, ensure_ascii=False)

def require_admin(func):
    @wraps(func)
    async def wrapper(message: Message, *args, **kwargs):
        user_id = message.from_user.id
        if ADMIN_ID is None:
            await message.answer("Адмін ID не налаштований.")
            return
        if user_id != ADMIN_ID:
            await message.answer("Доступ заборонено. Ця команда тільки для адміністратора.")
            return
        return await func(message, *args, **kwargs)
    return wrapper

def format_price(p):
    return f"${p:.2f}"

# --- Keyboards ---
def main_menu_kb():
    kb = InlineKeyboardMarkup(row_width=2, inline_keyboard=[
        [InlineKeyboardButton(text="Каталог 🛍️", callback_data="catalog"),
         InlineKeyboardButton(text="Переглянути кошик 🧾", callback_data="view_cart")],
        [InlineKeyboardButton(text="Мої замовлення", callback_data="my_orders")]
    ])
    return kb

def product_kb(product_id):
    kb = InlineKeyboardMarkup(row_width=2, inline_keyboard=[
        [InlineKeyboardButton(text="Додати в кошик ➕", callback_data=CatalogCallback(action="add", product_id=product_id).pack()),
         InlineKeyboardButton(text="Назад 🔙", callback_data="catalog")]
    ])
    return kb

async def cart_kb(user_id: int, state: FSMContext):
    data = await state.get_data()
    cart = data.get("cart", {})
    kb = InlineKeyboardMarkup(row_width=2, inline_keyboard=[])
    for pid, qty in cart.items():
        kb.inline_keyboard.append([
            InlineKeyboardButton(text=f"− {PRODUCTS[pid]['name']} ({qty})", callback_data=CartCallback(action="decrease", product_id=pid).pack()),
            InlineKeyboardButton(text="+", callback_data=CartCallback(action="increase", product_id=pid).pack())
        ])
    if cart:
        kb.inline_keyboard.append([
            InlineKeyboardButton(text="Оформити замовлення ✅", callback_data="checkout"),
            InlineKeyboardButton(text="Очистити кошик 🗑️", callback_data="clear_cart")
        ])
    kb.inline_keyboard.append([InlineKeyboardButton(text="Повернутися в меню 🔙", callback_data="menu")])
    return kb

# --- Handlers ---
@router.message(Command("start"))
async def cmd_start(message: Message, state: FSMContext):
    user = message.from_user
    await state.set_data({"cart": {}})
    text = f"Привіт, {user.first_name}! Це тестовий магазин девайсів для ПК.\nВибирай у меню 👇"
    await message.answer(text, reply_markup=main_menu_kb())

@router.callback_query(F.data == "menu")
async def cb_menu(query: types.CallbackQuery):
    await query.message.edit_text("Головне меню:", reply_markup=main_menu_kb())
    await query.answer()

@router.callback_query(F.data == "catalog")
async def cb_catalog(query: types.CallbackQuery):
    text_lines = ["🛍️ <b>Каталог товарів</b>:"]
    kb = InlineKeyboardMarkup(row_width=1, inline_keyboard=[])
    for pid, p in PRODUCTS.items():
        text_lines.append(f"\n<b>{p['name']}</b>\n{p['desc']}\nЦіна: {format_price(p['price'])} | В наявності: {p['stock']}")
        kb.inline_keyboard.append([InlineKeyboardButton(text=f"Дивитись: {p['name']}", callback_data=CatalogCallback(action="view", product_id=pid).pack())])
    kb.inline_keyboard.append([InlineKeyboardButton(text="Повернутися в меню 🔙", callback_data="menu")])
    
    # Видаляємо старе повідомлення і надсилаємо нове, щоб уникнути помилок при редагуванні
    await bot.delete_message(chat_id=query.message.chat.id, message_id=query.message.message_id)
    await bot.send_message(chat_id=query.message.chat.id, text="\n".join(text_lines), parse_mode=ParseMode.HTML, reply_markup=kb)
    
    await query.answer()

@router.callback_query(CatalogCallback.filter(F.action == "view"))
async def cb_catalog_view(query: types.CallbackQuery, callback_data: CatalogCallback):
    pid = callback_data.product_id
    p = PRODUCTS.get(pid)
    
    if not p or 'photo_id' not in p:
        await query.answer("Товар не знайдено або фото відсутнє", show_alert=True)
        return
    
    text = f"<b>{p['name']}</b>\n{p['desc']}\n\nЦіна: {format_price(p['price'])}\nВ наявності: {p['stock']}"
    
    # Видаляємо старе повідомлення
    await bot.delete_message(chat_id=query.message.chat.id, message_id=query.message.message_id)

    # Відправляємо нове повідомлення з фото
    try:
        await bot.send_photo(
            chat_id=query.message.chat.id,
            photo=p['photo_id'],
            caption=text,
            parse_mode=ParseMode.HTML,
            reply_markup=product_kb(pid)
        )
        await query.answer()
    except Exception as e:
        await query.answer(f"Помилка при відправці фото: {e}", show_alert=True)
        print(f"Помилка: {e}")

@router.callback_query(CatalogCallback.filter(F.action == "add"))
async def cb_catalog_add(query: types.CallbackQuery, callback_data: CatalogCallback, state: FSMContext):
    pid = callback_data.product_id
    p = PRODUCTS.get(pid)
    
    if not p:
        await query.answer("Товар не знайдено", show_alert=True)
        return
        
    data = await state.get_data()
    cart = data.get("cart", {})
    cart[pid] = cart.get(pid, 0) + 1
    await state.update_data(cart=cart)
    await query.answer(f"Додано {p['name']} до кошика ✅")

@router.callback_query(F.data == "view_cart")
async def cb_view_cart(query: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    cart = data.get("cart", {})
    if not cart:
        await query.answer()
        await query.message.edit_text("Кошик порожній. Додайте товари з каталогу.", reply_markup=main_menu_kb())
        return

    lines = ["🧾 <b>Ваш кошик</b>:"]
    total = 0.0
    for pid, qty in cart.items():
        p = PRODUCTS[pid]
        subtotal = p["price"] * qty
        total += subtotal
        lines.append(f"{p['name']} — {qty} × {format_price(p['price'])} = {format_price(subtotal)}")
    lines.append(f"\n<b>Всього: {format_price(total)}</b>")
    await query.message.edit_text("\n".join(lines), parse_mode=ParseMode.HTML, reply_markup=await cart_kb(query.from_user.id, state))
    await query.answer()

@router.callback_query(CartCallback.filter())
async def cb_cart_actions(query: types.CallbackQuery, callback_data: CartCallback, state: FSMContext):
    action = callback_data.action
    pid = callback_data.product_id
    data = await state.get_data()
    cart = data.get("cart", {})
    if pid not in cart:
        await query.answer("Товар не в кошику", show_alert=True)
        return

    if action == "increase":
        cart[pid] += 1
    elif action == "decrease":
        cart[pid] -= 1
        if cart[pid] <= 0:
            del cart[pid]
    await state.update_data(cart=cart)
    await query.answer("Оновлено кошик")
    await cb_view_cart(query, state)

@router.callback_query(F.data == "clear_cart")
async def cb_clear_cart(query: types.CallbackQuery, state: FSMContext):
    await state.update_data(cart={})
    await query.answer("Кошик очищено")
    await query.message.edit_text("Кошик очищено.", reply_markup=main_menu_kb())

# --- Checkout flow ---
@router.callback_query(F.data == "checkout")
async def cb_checkout(query: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    cart = data.get("cart", {})
    if not cart:
        await query.answer("Кошик порожній", show_alert=True)
        return

    await state.set_state(Checkout.ask_name)
    await query.message.answer("🔖 Вкажіть, будь ласка, ім'я отримувача:")
    await query.answer()

@router.message(Checkout.ask_name)
async def process_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(Checkout.ask_phone)
    await message.answer("📞 Вкажіть телефон (наприклад +380XXXXXXXXX):")

@router.message(Checkout.ask_phone)
async def process_phone(message: Message, state: FSMContext):
    await state.update_data(phone=message.text.strip())
    await state.set_state(Checkout.ask_address)
    await message.answer("🏠 Вкажіть адресу доставки (місто, вулиця, номер):")

@router.message(Checkout.ask_address)
async def process_address(message: Message, state: FSMContext):
    await state.update_data(address=message.text.strip())
    data = await state.get_data()
    cart = data.get("cart", {})
    
    lines = [f"🧾 <b>Підтвердження замовлення</b>\nІм'я: {data['name']}\nТелефон: {data['phone']}\nАдреса: {data['address']}\n\nТовари:"]
    total = 0.0
    for pid, qty in cart.items():
        p = PRODUCTS[pid]
        subtotal = p["price"] * qty
        total += subtotal
        lines.append(f"{p['name']} — {qty} × {format_price(p['price'])} = {format_price(subtotal)}")
    lines.append(f"\n<b>Всього до оплати: {format_price(total)}</b>")

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Симулювати оплату 💳", callback_data="simulate_pay")],
        [InlineKeyboardButton(text="Скасувати", callback_data="cancel_checkout")]
    ])
    
    await state.set_state(Checkout.confirm)
    await message.answer("\n".join(lines), parse_mode=ParseMode.HTML, reply_markup=kb)

@router.callback_query(F.data == "cancel_checkout", Checkout.confirm)
async def cb_cancel_checkout(query: types.CallbackQuery, state: FSMContext):
    await state.clear()
    await query.message.edit_text("Оформлення замовлення скасовано.", reply_markup=main_menu_kb())
    await query.answer()

@router.callback_query(F.data == "simulate_pay", Checkout.confirm)
async def cb_simulate_payment(query: types.CallbackQuery, state: FSMContext):
    uid = query.from_user.id
    data = await state.get_data()
    cart = data.get("cart", {})
    if not data or not cart:
        await query.answer("Немає даних для оплати", show_alert=True)
        return

    await query.answer("Проведення оплати...", show_alert=False)
    await asyncio.sleep(1)

    orders = load_orders()
    order_id = str(uuid4())[:8]
    total = sum(PRODUCTS[pid]["price"] * qty for pid, qty in cart.items())
    order = {
        "order_id": order_id,
        "created_at": datetime.utcnow().isoformat() + "Z",
        "user_id": uid,
        "user_name": data["name"],
        "phone": data["phone"],
        "address": data["address"],
        "items": [{"product_id": pid, "name": PRODUCTS[pid]["name"], "qty": qty, "price": PRODUCTS[pid]["price"]} for pid, qty in cart.items()],
        "total": total,
        "status": "paid"
    }
    orders.append(order)
    save_orders(orders)
    
    await state.clear()
    text = f"✅ Оплата пройшла успішно!\nНомер вашого замовлення: <b>{order_id}</b>\nМи зв'яжемося з вами для підтвердження."
    await query.message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=main_menu_kb())
    await query.answer("Оплата успішна ✅")

    if ADMIN_ID:
        try:
            order_text = f"📬 Нове замовлення #{order_id}\nКлієнт: {order['user_name']} ({order['phone']})\nАдреса: {order['address']}\nСума: {format_price(order['total'])}"
            kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Деталі", callback_data=OrderCallback(action="details", order_id=order_id).pack())]])
            await bot.send_message(ADMIN_ID, order_text, reply_markup=kb)
        except Exception as e:
            logger.exception("Не вдалось надіслати адміну повідомлення: %s", e)

# --- Admin: list orders ---
@router.message(Command("orders"))
@require_admin
async def cmd_orders(message: Message):
    orders = load_orders()
    if not orders:
        await message.answer("Поки що немає замовлень.")
        return
    kb = InlineKeyboardMarkup(row_width=1, inline_keyboard=[])
    for o in orders[::-1]:
        short = f"#{o['order_id']} — {format_price(o['total'])} — {o['status']}"
        kb.inline_keyboard.append([InlineKeyboardButton(text=short, callback_data=OrderCallback(action="details", order_id=o["order_id"]).pack())])
    await message.answer("Список замовлень:", reply_markup=kb)

@router.callback_query(OrderCallback.filter())
async def cb_order_actions(query: types.CallbackQuery, callback_data: OrderCallback):
    action = callback_data.action
    oid = callback_data.order_id
    orders = load_orders()
    order = next((o for o in orders if o["order_id"] == oid), None)
    if not order:
        await query.answer("Замовлення не знайдено", show_alert=True)
        return

    if action == "details":
        lines = [
            f"📦 <b>Замовлення #{order['order_id']}</b>",
            f"Створено: {order['created_at']}",
            f"Клієнт: {order['user_name']} (ID: {order['user_id']})",
            f"Телефон: {order['phone']}",
            f"Адреса: {order['address']}",
            "\nТовари:"
        ]
        for it in order["items"]:
            lines.append(f"{it['name']} — {it['qty']} × {format_price(it['price'])}")
        lines.append(f"\n<b>Сума: {format_price(order['total'])}</b>")
        lines.append(f"Статус: {order['status']}")
        
        kb = InlineKeyboardMarkup(inline_keyboard=[])
        if order["status"] != "shipped":
            kb.inline_keyboard.append([InlineKeyboardButton(text="Позначити як відправлене ✅", callback_data=OrderCallback(action="mark_shipped", order_id=oid).pack())])
        kb.inline_keyboard.append([InlineKeyboardButton(text="Закрити", callback_data="menu")])
        
        await query.message.edit_text("\n".join(lines), parse_mode=ParseMode.HTML, reply_markup=kb)
        await query.answer()

    elif action == "mark_shipped":
        for o in orders:
            if o["order_id"] == oid:
                o["status"] = "shipped"
                break
        save_orders(orders)
        await query.answer("Позначено як відправлене")
        await cb_order_actions(query, callback_data=OrderCallback(action="details", order_id=oid))

# --- User: view own orders ---
@router.callback_query(F.data == "my_orders")
async def cb_my_orders(query: types.CallbackQuery):
    user_id = query.from_user.id
    orders = load_orders()
    user_orders = [o for o in orders if o["user_id"] == user_id]
    if not user_orders:
        await query.answer()
        await query.message.edit_text("У вас поки немає замовлень.", reply_markup=main_menu_kb())
        return

    lines = ["Ваші замовлення:"]
    kb = InlineKeyboardMarkup(row_width=1, inline_keyboard=[])
    for o in user_orders[::-1]:
        lines.append(f"#{o['order_id']} — {format_price(o['total'])} — {o['status']}")
        kb.inline_keyboard.append([InlineKeyboardButton(text=f"Деталі #{o['order_id']}", callback_data=OrderCallback(action="user_details", order_id=o["order_id"]).pack())])
    kb.inline_keyboard.append([InlineKeyboardButton(text="Повернутися в меню 🔙", callback_data="menu")])
    
    await query.message.edit_text("\n".join(lines), reply_markup=kb)
    await query.answer()

@router.callback_query(OrderCallback.filter(F.action == "user_details"))
async def cb_user_order_details(query: types.CallbackQuery, callback_data: OrderCallback):
    oid = callback_data.order_id
    orders = load_orders()
    order = next((o for o in orders if o["order_id"] == oid and o["user_id"] == query.from_user.id), None)
    if not order:
        await query.answer("Замовлення не знайдено", show_alert=True)
        return

    lines = [
        f"📦 <b>Замовлення #{order['order_id']}</b>",
        f"Статус: {order['status']}",
        f"Сума: {format_price(order['total'])}",
        "\nТовари:"
    ]
    for it in order["items"]:
        lines.append(f"{it['name']} — {it['qty']} × {format_price(it['price'])}")
    
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Повернутися", callback_data="my_orders")]])
    await query.message.edit_text("\n".join(lines), parse_mode=ParseMode.HTML, reply_markup=kb)
    await query.answer()

# --- Fallback text handler for help ---
@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer("/start — запустити бота\nКаталог, Кошик, Оформлення замовлення через меню.\nАдмін: /orders")
    
# --- Temporary photo ID handler ---
@router.message(F.photo)
async def get_photo_id(message: types.Message):
    photo_id = message.photo[-1].file_id
    await message.answer(f"ID цього фото: `{photo_id}`")

async def main():
    dp.include_router(router)
    print("Bot starting...")
    await dp.start_polling(bot, skip_updates=True)

if __name__ == "__main__":
    asyncio.run(main())